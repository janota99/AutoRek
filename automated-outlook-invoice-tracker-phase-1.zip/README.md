# Automated Outlook Invoice Tracker

Phase 1 foundation for a B2B accounts receivable and accounts payable workflow portal. The application uses Node.js, Express, PostgreSQL, and explicit SQL migrations. Microsoft Graph ingestion and the browser dashboard are intentionally reserved for later phases.

## Phase 1 contents

- Express 5 REST API with security headers, CORS, JSON limits, and centralized errors
- PostgreSQL schema for AR/AP invoice items, exceptions, duplicate review, status history, and Graph delta synchronization
- Dynamic aging calculations through a database view
- Idempotency constraints for Graph messages and attachments
- Filtered and paginated invoice API
- Transactional workflow-status updates with an audit trail
- Synthetic seed records and automated API/validation tests

## Project structure

```text
automated-outlook-invoice-tracker/
├── migrations/
│   └── 001_initial_schema.sql
├── src/
│   ├── config/env.js
│   ├── db/{migrate,pool,seed}.js
│   ├── middleware/error-handler.js
│   ├── repositories/invoice-repository.js
│   ├── routes/{health,invoices}.js
│   ├── utils/http-error.js
│   ├── app.js
│   └── server.js
├── tests/
├── .env.example
├── docker-compose.yml
└── package.json
```

## Prerequisites

- Node.js 22 or newer
- PostgreSQL 15 or newer, either installed locally or run through Docker Desktop

You currently only need Node.js to install dependencies and run unit tests. PostgreSQL is required when running migrations or using database-backed API routes.

## Setup

1. Open a terminal in this project directory.
2. Install packages:

   ```bash
   npm install
   ```

3. Copy `.env.example` to `.env`. Change the local database password before using anything beyond a private development machine.
4. Start PostgreSQL. If Docker Desktop is later installed:

   ```bash
   docker compose up -d
   ```

5. Build and seed the local database:

   ```bash
   npm run db:setup
   ```

6. Start the API:

   ```bash
   npm run dev
   ```

7. Open `http://localhost:3000/api` or `http://localhost:3000/api/health`.

## Test

```bash
npm test
```

The test suite uses dependency injection and does not require PostgreSQL.

## Initial API routes

| Method | Route | Purpose |
| --- | --- | --- |
| `GET` | `/api` | API name, version, and phase |
| `GET` | `/api/health` | API and PostgreSQL health |
| `GET` | `/api/invoices` | Paginated, sortable, filtered invoice items |
| `GET` | `/api/invoices/:id` | One invoice with status history |
| `PATCH` | `/api/invoices/:id/status` | Transactional status update |

Supported list filters include `sourceType`, `status`, `agingBucket`, `isException`, `isDuplicate`, and `search`. Pagination uses `page` and `pageSize`.

## Important schema decisions

- **Aging is computed, not stored.** `days_active` and `aging_bucket` come from `invoice_items_with_aging`, preventing stale daily values. The received business date is derived in the `America/Chicago` timezone so late-night UTC timestamps do not shift a Texas business date.
- **Graph IDs are retained.** Unique partial indexes prevent the same AR message or AP attachment from being imported twice.
- **Potential business duplicates are different from ingestion duplicates.** A repeated invoice number or attachment name can still be saved and linked through `duplicate_of_id`; Graph source uniqueness only prevents reprocessing the identical source object.
- **Status changes are auditable.** Each change is saved to `invoice_status_history` in the same transaction as the invoice update.
- **Exceptions are explicit.** An exception must include a reason, so failures cannot become unexplained flags.

## Security notes

- Never commit `.env` or a Microsoft client secret.
- Do not use an Outlook password. Phase 2 will use Microsoft Entra ID and OAuth 2.0.
- Use synthetic data for school demonstrations unless your employer explicitly approves real company data.
- The default Docker password is for local development only and must be changed before any shared or hosted environment.

## Planned Phase 2

- Create the private GitHub repository and initial commit
- Register the Microsoft Entra ID application
- Configure least-privilege Microsoft Graph permissions
- Add MSAL Node authentication and token handling
- Resolve and store the two Outlook folder IDs
- Define the safe approach for local development versus a school demonstration
