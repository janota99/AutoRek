CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE invoice_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  source_type VARCHAR(2) NOT NULL CHECK (source_type IN ('AR', 'AP')),
  source_folder TEXT NOT NULL,
  graph_message_id TEXT,
  graph_attachment_id TEXT,
  email_subject TEXT,
  email_received_at TIMESTAMPTZ NOT NULL,
  vendor_customer_name TEXT,
  invoice_number TEXT,
  bol_number TEXT,
  attachment_name TEXT,
  web_link TEXT,
  status VARCHAR(20) NOT NULL DEFAULT 'Received'
    CHECK (status IN ('Received', 'Approved', 'Paid', 'Disputed', 'Archived')),
  date_received DATE GENERATED ALWAYS AS (
    (email_received_at AT TIME ZONE 'America/Chicago')::date
  ) STORED,
  is_duplicate BOOLEAN NOT NULL DEFAULT FALSE,
  duplicate_of_id UUID REFERENCES invoice_items(id) ON DELETE RESTRICT,
  is_exception BOOLEAN NOT NULL DEFAULT FALSE,
  exception_reason TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT ar_is_message_level CHECK (
    source_type <> 'AR' OR graph_attachment_id IS NULL
  ),
  CONSTRAINT ap_attachment_consistency CHECK (
    source_type <> 'AP' OR graph_attachment_id IS NOT NULL OR is_exception
  ),
  CONSTRAINT exception_has_reason CHECK (
    NOT is_exception OR NULLIF(BTRIM(exception_reason), '') IS NOT NULL
  ),
  CONSTRAINT duplicate_has_reference CHECK (
    NOT is_duplicate OR duplicate_of_id IS NOT NULL
  )
);

CREATE UNIQUE INDEX uq_invoice_items_ar_graph_message
  ON invoice_items (graph_message_id)
  WHERE source_type = 'AR' AND graph_message_id IS NOT NULL;

CREATE UNIQUE INDEX uq_invoice_items_ap_graph_attachment
  ON invoice_items (graph_message_id, graph_attachment_id)
  WHERE source_type = 'AP'
    AND graph_message_id IS NOT NULL
    AND graph_attachment_id IS NOT NULL;

CREATE INDEX idx_invoice_items_source_status
  ON invoice_items (source_type, status);

CREATE INDEX idx_invoice_items_received
  ON invoice_items (email_received_at DESC);

CREATE INDEX idx_invoice_items_invoice_number_normalized
  ON invoice_items (LOWER(BTRIM(invoice_number)))
  WHERE invoice_number IS NOT NULL;

CREATE INDEX idx_invoice_items_attachment_name_normalized
  ON invoice_items (LOWER(BTRIM(attachment_name)))
  WHERE attachment_name IS NOT NULL;

CREATE INDEX idx_invoice_items_exception_queue
  ON invoice_items (email_received_at DESC)
  WHERE is_exception;

CREATE INDEX idx_invoice_items_duplicate_queue
  ON invoice_items (email_received_at DESC)
  WHERE is_duplicate;

CREATE TABLE invoice_status_history (
  id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  invoice_item_id UUID NOT NULL REFERENCES invoice_items(id) ON DELETE CASCADE,
  previous_status VARCHAR(20),
  new_status VARCHAR(20) NOT NULL
    CHECK (new_status IN ('Received', 'Approved', 'Paid', 'Disputed', 'Archived')),
  changed_by TEXT NOT NULL DEFAULT 'system',
  change_note TEXT,
  changed_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_status_history_item_time
  ON invoice_status_history (invoice_item_id, changed_at DESC);

CREATE TABLE graph_sync_state (
  source_type VARCHAR(2) PRIMARY KEY CHECK (source_type IN ('AR', 'AP')),
  folder_id TEXT NOT NULL,
  delta_link TEXT,
  last_successful_sync_at TIMESTAMPTZ,
  last_attempted_sync_at TIMESTAMPTZ,
  last_error TEXT,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER invoice_items_set_updated_at
BEFORE UPDATE ON invoice_items
FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TRIGGER graph_sync_state_set_updated_at
BEFORE UPDATE ON graph_sync_state
FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE VIEW invoice_items_with_aging AS
SELECT
  item.*,
  CASE
    WHEN item.status IN ('Paid', 'Archived') THEN 0
    ELSE GREATEST(CURRENT_DATE - item.date_received, 0)
  END AS days_active,
  CASE
    WHEN item.status IN ('Paid', 'Archived') THEN 'Closed'
    WHEN CURRENT_DATE - item.date_received <= 0 THEN 'Current'
    WHEN CURRENT_DATE - item.date_received <= 30 THEN '1-30'
    WHEN CURRENT_DATE - item.date_received <= 60 THEN '31-60'
    WHEN CURRENT_DATE - item.date_received <= 90 THEN '61-90'
    ELSE '90+'
  END AS aging_bucket
FROM invoice_items item;

COMMENT ON VIEW invoice_items_with_aging IS
  'Calculates days active and aging at query time so dashboard values never become stale.';
