import cors from "cors";
import express from "express";
import helmet from "helmet";
import { env } from "./config/env.js";
import { errorHandler, notFoundHandler } from "./middleware/error-handler.js";
import { createHealthRouter } from "./routes/health.js";
import { createInvoicesRouter } from "./routes/invoices.js";

export function createApp(options = {}) {
  const app = express();

  app.disable("x-powered-by");
  app.use(helmet());
  app.use(cors({ origin: env.CORS_ORIGIN }));
  app.use(express.json({ limit: "1mb" }));

  app.get("/api", (req, res) => {
    res.json({
      name: "Automated Outlook Invoice Tracker API",
      version: "0.1.0",
      phase: 1
    });
  });
  app.use("/api/health", createHealthRouter(options.health));
  app.use("/api/invoices", createInvoicesRouter(options.invoiceRepository));

  app.use(notFoundHandler);
  app.use(errorHandler);

  return app;
}
