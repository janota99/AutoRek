import { pool, query } from "../db/pool.js";

const sortableColumns = new Map([
  ["emailReceivedAt", "email_received_at"],
  ["vendorCustomerName", "vendor_customer_name"],
  ["invoiceNumber", "invoice_number"],
  ["status", "status"],
  ["daysActive", "days_active"]
]);

export async function listInvoices(filters) {
  const conditions = [];
  const values = [];

  const addCondition = (sql, value) => {
    values.push(value);
    conditions.push(sql.replace("?", `$${values.length}`));
  };

  if (filters.sourceType) addCondition("source_type = ?", filters.sourceType);
  if (filters.status) addCondition("status = ?", filters.status);
  if (filters.agingBucket) addCondition("aging_bucket = ?", filters.agingBucket);
  if (filters.isException !== undefined) addCondition("is_exception = ?", filters.isException);
  if (filters.isDuplicate !== undefined) addCondition("is_duplicate = ?", filters.isDuplicate);
  if (filters.search) {
    addCondition(
      "CONCAT_WS(' ', vendor_customer_name, invoice_number, bol_number, attachment_name, email_subject) ILIKE ?",
      `%${filters.search}%`
    );
  }

  const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
  const sortColumn = sortableColumns.get(filters.sortBy) ?? "email_received_at";
  const sortDirection = filters.sortDirection === "asc" ? "ASC" : "DESC";
  const offset = (filters.page - 1) * filters.pageSize;

  values.push(filters.pageSize, offset);
  const limitPosition = values.length - 1;
  const offsetPosition = values.length;

  const [itemsResult, countResult] = await Promise.all([
    query(
      `SELECT * FROM invoice_items_with_aging
       ${where}
       ORDER BY ${sortColumn} ${sortDirection}, id
       LIMIT $${limitPosition} OFFSET $${offsetPosition}`,
      values
    ),
    query(`SELECT COUNT(*)::integer AS total FROM invoice_items_with_aging ${where}`, values.slice(0, -2))
  ]);

  return { items: itemsResult.rows, total: countResult.rows[0].total };
}

export async function findInvoiceById(id) {
  const result = await query(
    `SELECT item.*,
       COALESCE(
         JSON_AGG(history ORDER BY history.changed_at DESC)
           FILTER (WHERE history.id IS NOT NULL),
         '[]'::json
       ) AS status_history
     FROM invoice_items_with_aging item
     LEFT JOIN invoice_status_history history ON history.invoice_item_id = item.id
     WHERE item.id = $1
     GROUP BY item.id, item.source_type, item.source_folder, item.graph_message_id,
       item.graph_attachment_id, item.email_subject, item.email_received_at,
       item.vendor_customer_name, item.invoice_number, item.bol_number,
       item.attachment_name, item.web_link, item.status, item.date_received,
       item.is_duplicate, item.duplicate_of_id, item.is_exception,
       item.exception_reason, item.created_at, item.updated_at,
       item.days_active, item.aging_bucket`,
    [id]
  );
  return result.rows[0] ?? null;
}

export async function updateInvoiceStatus(id, newStatus, changedBy, note) {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const current = await client.query(
      "SELECT status FROM invoice_items WHERE id = $1 FOR UPDATE",
      [id]
    );
    if (!current.rowCount) {
      await client.query("ROLLBACK");
      return null;
    }

    const previousStatus = current.rows[0].status;
    const updated = await client.query(
      "UPDATE invoice_items SET status = $2 WHERE id = $1 RETURNING *",
      [id, newStatus]
    );
    await client.query(
      `INSERT INTO invoice_status_history
       (invoice_item_id, previous_status, new_status, changed_by, change_note)
       VALUES ($1, $2, $3, $4, $5)`,
      [id, previousStatus, newStatus, changedBy, note ?? null]
    );
    await client.query("COMMIT");
    return updated.rows[0];
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}
