import { ZodError } from "zod";

export function notFoundHandler(req, res) {
  res.status(404).json({
    error: {
      code: "NOT_FOUND",
      message: `No route exists for ${req.method} ${req.originalUrl}`
    }
  });
}

export function errorHandler(error, req, res, next) {
  if (res.headersSent) return next(error);

  if (error instanceof ZodError) {
    return res.status(400).json({
      error: {
        code: "VALIDATION_ERROR",
        message: "The request contains invalid values.",
        details: error.issues
      }
    });
  }

  const status = Number.isInteger(error.status) ? error.status : 500;
  const publicMessage = status >= 500 ? "An unexpected server error occurred." : error.message;

  if (status >= 500) console.error(error);

  return res.status(status).json({
    error: {
      code: error.code ?? "INTERNAL_ERROR",
      message: publicMessage,
      ...(error.details ? { details: error.details } : {})
    }
  });
}
