import { pool } from "./pool.js";

const sampleItems = [
  {
    sourceType: "AR",
    sourceFolder: "Inbox > Panhandle Pure > ACCTINV",
    graphMessageId: "sample-ar-message-001",
    emailSubject: "Northwind Market Invoice INV-1042 BOL 77881",
    vendorCustomerName: "Northwind Market",
    invoiceNumber: "INV-1042",
    bolNumber: "77881",
    status: "Received",
    daysAgo: 12
  },
  {
    sourceType: "AP",
    sourceFolder: "Inbox > Panhandle Pure > Payables > Bills",
    graphMessageId: "sample-ap-message-001",
    graphAttachmentId: "sample-attachment-001",
    emailSubject: "Monthly packaging invoice",
    attachmentName: "Contoso Packaging 88419.pdf",
    vendorCustomerName: "Contoso Packaging",
    invoiceNumber: "88419",
    status: "Approved",
    daysAgo: 37
  }
];

async function seed() {
  for (const item of sampleItems) {
    await pool.query(
      `INSERT INTO invoice_items (
         source_type, source_folder, graph_message_id, graph_attachment_id,
         email_subject, email_received_at, vendor_customer_name, invoice_number,
         bol_number, attachment_name, status
       )
       VALUES ($1, $2, $3, $4, $5, NOW() - ($6 * INTERVAL '1 day'), $7, $8, $9, $10, $11)
       ON CONFLICT DO NOTHING`,
      [
        item.sourceType,
        item.sourceFolder,
        item.graphMessageId,
        item.graphAttachmentId ?? null,
        item.emailSubject,
        item.daysAgo,
        item.vendorCustomerName,
        item.invoiceNumber,
        item.bolNumber ?? null,
        item.attachmentName ?? null,
        item.status
      ]
    );
  }

  console.log("Synthetic development data seeded.");
  await pool.end();
}

seed().catch((error) => {
  console.error("Seeding failed", error);
  process.exitCode = 1;
});
