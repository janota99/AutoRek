import { Router } from "express";
import { query } from "../db/pool.js";

export function createHealthRouter({ databaseQuery = query } = {}) {
  const router = Router();

  router.get("/", async (req, res) => {
    let database = "connected";
    let status = 200;

    try {
      await databaseQuery("SELECT 1");
    } catch {
      database = "unavailable";
      status = 503;
    }

    res.status(status).json({
      status: status === 200 ? "ok" : "degraded",
      database,
      timestamp: new Date().toISOString()
    });
  });

  return router;
}
