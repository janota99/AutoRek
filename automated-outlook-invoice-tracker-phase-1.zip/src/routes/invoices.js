import { Router } from "express";
import { z } from "zod";
import {
  findInvoiceById,
  listInvoices,
  updateInvoiceStatus
} from "../repositories/invoice-repository.js";
import { HttpError } from "../utils/http-error.js";

const statusSchema = z.enum(["Received", "Approved", "Paid", "Disputed", "Archived"]);
const booleanQuery = z.enum(["true", "false"]).transform((value) => value === "true");

const listQuerySchema = z.object({
  sourceType: z.enum(["AR", "AP"]).optional(),
  status: statusSchema.optional(),
  agingBucket: z.enum(["Current", "1-30", "31-60", "61-90", "90+", "Closed"]).optional(),
  isException: booleanQuery.optional(),
  isDuplicate: booleanQuery.optional(),
  search: z.string().trim().max(100).optional(),
  page: z.coerce.number().int().positive().default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(25),
  sortBy: z
    .enum(["emailReceivedAt", "vendorCustomerName", "invoiceNumber", "status", "daysActive"])
    .default("emailReceivedAt"),
  sortDirection: z.enum(["asc", "desc"]).default("desc")
});

const idSchema = z.string().uuid();
const statusUpdateSchema = z.object({
  status: statusSchema,
  changedBy: z.string().trim().min(1).max(200).default("portal-user"),
  note: z.string().trim().max(500).optional()
});

export function createInvoicesRouter(repository = {
  findInvoiceById,
  listInvoices,
  updateInvoiceStatus
}) {
  const router = Router();

  router.get("/", async (req, res) => {
    const filters = listQuerySchema.parse(req.query);
    const result = await repository.listInvoices(filters);
    res.json({
      data: result.items,
      pagination: {
        page: filters.page,
        pageSize: filters.pageSize,
        total: result.total,
        totalPages: Math.ceil(result.total / filters.pageSize)
      }
    });
  });

  router.get("/:id", async (req, res) => {
    const id = idSchema.parse(req.params.id);
    const invoice = await repository.findInvoiceById(id);
    if (!invoice) throw new HttpError(404, "Invoice item was not found.");
    res.json({ data: invoice });
  });

  router.patch("/:id/status", async (req, res) => {
    const id = idSchema.parse(req.params.id);
    const update = statusUpdateSchema.parse(req.body);
    const invoice = await repository.updateInvoiceStatus(
      id,
      update.status,
      update.changedBy,
      update.note
    );
    if (!invoice) throw new HttpError(404, "Invoice item was not found.");
    res.json({ data: invoice });
  });

  return router;
}

export { listQuerySchema, statusUpdateSchema };
