import { describe, expect, it } from "vitest";
import { listQuerySchema, statusUpdateSchema } from "../src/routes/invoices.js";

describe("request schemas", () => {
  it("applies safe pagination defaults", () => {
    const parsed = listQuerySchema.parse({});
    expect(parsed).toMatchObject({ page: 1, pageSize: 25, sortDirection: "desc" });
  });

  it("converts boolean query parameters", () => {
    const parsed = listQuerySchema.parse({ isException: "true", isDuplicate: "false" });
    expect(parsed.isException).toBe(true);
    expect(parsed.isDuplicate).toBe(false);
  });

  it("rejects unsupported workflow statuses", () => {
    expect(() => statusUpdateSchema.parse({ status: "Deleted" })).toThrow();
  });
});
