import request from "supertest";
import { describe, expect, it, vi } from "vitest";
import { createApp } from "../src/app.js";

const sampleId = "5ed7316b-a66c-4c73-95f4-9d6ff17bc991";

function createRepository() {
  return {
    listInvoices: vi.fn().mockResolvedValue({ items: [], total: 0 }),
    findInvoiceById: vi.fn().mockResolvedValue(null),
    updateInvoiceStatus: vi.fn().mockResolvedValue(null)
  };
}

describe("API foundation", () => {
  it("reports API metadata", async () => {
    const app = createApp({
      health: { databaseQuery: vi.fn().mockResolvedValue({ rows: [{ "?column?": 1 }] }) },
      invoiceRepository: createRepository()
    });
    const response = await request(app).get("/api");
    expect(response.status).toBe(200);
    expect(response.body).toMatchObject({ version: "0.1.0", phase: 1 });
  });

  it("reports a healthy database connection", async () => {
    const app = createApp({
      health: { databaseQuery: vi.fn().mockResolvedValue({}) },
      invoiceRepository: createRepository()
    });
    const response = await request(app).get("/api/health");
    expect(response.status).toBe(200);
    expect(response.body.database).toBe("connected");
  });

  it("reports degraded health when PostgreSQL is unavailable", async () => {
    const app = createApp({
      health: { databaseQuery: vi.fn().mockRejectedValue(new Error("offline")) },
      invoiceRepository: createRepository()
    });
    const response = await request(app).get("/api/health");
    expect(response.status).toBe(503);
    expect(response.body.status).toBe("degraded");
  });

  it("validates invoice filters", async () => {
    const app = createApp({ invoiceRepository: createRepository() });
    const response = await request(app).get("/api/invoices?sourceType=INVALID");
    expect(response.status).toBe(400);
    expect(response.body.error.code).toBe("VALIDATION_ERROR");
  });

  it("updates status through the injected repository", async () => {
    const repository = createRepository();
    repository.updateInvoiceStatus.mockResolvedValue({ id: sampleId, status: "Paid" });
    const app = createApp({ invoiceRepository: repository });
    const response = await request(app)
      .patch(`/api/invoices/${sampleId}/status`)
      .send({ status: "Paid", changedBy: "Dylan" });
    expect(response.status).toBe(200);
    expect(response.body.data.status).toBe("Paid");
    expect(repository.updateInvoiceStatus).toHaveBeenCalledWith(
      sampleId,
      "Paid",
      "Dylan",
      undefined
    );
  });
});
